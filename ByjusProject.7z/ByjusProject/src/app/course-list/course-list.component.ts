import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { DomSanitizer } from '@angular/platform-browser';
import { EmbedVideoService } from 'ngx-embed-video';


@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {
  iframe_html: any;
  youtubeUrl = "https://www.youtube.com/watch?v=iHhcHTlGtRs";
  constructor(private dataService: DataService, private embedService: EmbedVideoService) {
    this.iframe_html = this.embedService.embed(this.youtubeUrl);
   }

  courseData: any = [];
  providers: any = [];
  universites: any = [];
  childSubject: any = [];
  selected: any;
  orignalCourseData: any =[];
  subject:any = [];
  ngOnInit() {
    this.getCourseList();
  }

  getCourseList(){
    this.dataService.getCourseListData().subscribe((courseData)=>{
      this.courseData = courseData;
      this.orignalCourseData = courseData;
      this.getProviders(this.courseData);
      this.getUniversities(this.courseData);
      this.getChildSubjects(this.courseData);
      this.getSubjects(this.courseData);

    })
  }

  getProviders(courseData: any){
    for(let i = 0; i < courseData.length ;i++){
      if(!this.providers.includes(courseData[i].Provider)){
        this.providers.push(courseData[i].Provider);
      }
    }
    console.log(this.providers);
  }
  getUniversities(courseData: any){
    for(let i = 0; i < courseData.length ;i++){
      if(!this.universites.includes(courseData[i]["Universities"]["Institutions"])){
        this.universites.push(courseData[i]["Universities"]["Institutions"]);
      }
    }
    console.log(this.universites);
  }
  getChildSubjects(courseData: any){
    for(let i = 0; i < courseData.length ;i++){
      if(!this.childSubject.includes(courseData[i]["Child Subject"])){
        this.childSubject.push(courseData[i]["Child Subject"]);
      }
    }
    console.log(this.childSubject);
  }

  getSubjects(courseData: any){
    for(let i = 0; i < courseData.length ;i++){
      if(!this.subject.includes(courseData[i]["Parent Subject"])){
        this.subject.push(courseData[i]["Parent Subject"]);
      }
    }
    console.log(this.childSubject);
  }
  changeProvider(value : any){
    console.log(value);
    this.courseData = this.orignalCourseData;
    let data = [];
    for(let i = 0; i < this.courseData.length ;i++){
      if(this.courseData[i].Provider == value){
        data.push(this.courseData[i]);
      }
    }
    this.courseData = data;
  }
  changeSubject(value : any){
    console.log(value);
    this.courseData = this.orignalCourseData;
    let data = [];
    for(let i = 0; i < this.courseData.length ;i++){
      if(this.courseData[i]["Child Subject"] == value){
        data.push(this.courseData[i]);
      }
    }
    this.courseData = data;
  }
  changeUniversity(value : any){
    console.log(value);
    this.courseData = this.orignalCourseData;
    let data = [];
    for(let i = 0; i < this.courseData.length ;i++){
      if(this.courseData[i]["Universities"]["Institutions"] == value){
        data.push(this.courseData[i]);
      }
    }
    this.courseData = data;
  }
  changeParentSubject(value : any){
    console.log(value);
    this.courseData = this.orignalCourseData;
    let data = [];
    for(let i = 0; i < this.courseData.length ;i++){
      if(this.courseData[i]["Parent Subject"] == value){
        data.push(this.courseData[i]);
      }
    }
    this.courseData = data;
  }

}
