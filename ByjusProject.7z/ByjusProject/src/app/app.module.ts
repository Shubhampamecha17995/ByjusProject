import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from "@angular/forms";
import { AppComponent } from './app.component';
import { CourseListComponent } from './course-list/course-list.component';
import {HttpClientModule} from '@angular/common/http';
import { DataService } from './data.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  MatInputModule,
  MatCardModule,
  MatButtonModule,
  MatToolbarModule,
  MatExpansionModule
} from "@angular/material";
import {MatGridListModule} from '@angular/material/grid-list';
import {MatSelectModule} from '@angular/material/select';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatDatepickerModule,MatNativeDateModule } from '@angular/material';
import { EmbedVideo } from 'ngx-embed-video';

@NgModule({
  declarations: [
    AppComponent,
    CourseListComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    MatInputModule,
    MatCardModule,
    MatButtonModule,
    MatToolbarModule,
    MatExpansionModule,MatGridListModule,
    MatSelectModule,
    BrowserAnimationsModule,MatFormFieldModule,
    MatDatepickerModule,MatNativeDateModule,
    EmbedVideo.forRoot()
  ],
  providers: [DataService,MatDatepickerModule],
  bootstrap: [AppComponent]
})
export class AppModule { }
